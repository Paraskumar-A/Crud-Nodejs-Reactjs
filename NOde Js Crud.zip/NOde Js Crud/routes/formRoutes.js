const express = require("express");
const Form = require("../models/form");
const router = express.Router();

// Create a new form template
router.post("/templates", async (req, res) => {
  try {
    const form = new Form({
      formName: req.body.formName,
      fields: req.body.fields,
    });
    await form.save();
    res.status(201).json(form);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get all form templates
router.get("/templates", async (req, res) => {
  try {
    const forms = await Form.find();
    res.json(forms);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get a specific form template
router.get("/templates/:id", async (req, res) => {
  try {
    const form = await Form.findById(req.params.id);
    if (!form) return res.status(404).json({ error: "Form not found" });
    res.json(form);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Submit form data
router.post("/submit/:formId", async (req, res) => {
  try {
    const form = await Form.findById(req.params.formId);
    if (!form) return res.status(404).json({ error: "Form not found" });

    form.submissions.push({
      data: req.body,
      submittedBy: req.body.userId, // Optional: if you have user authentication
    });

    await form.save();
    res.status(201).json({ message: "Form submitted successfully" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get all submissions for a form
router.get("/submissions/:formId", async (req, res) => {
  try {
    const form = await Form.findById(req.params.formId);
    if (!form) return res.status(404).json({ error: "Form not found" });
    res.json(form.submissions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
