const mongoose = require("mongoose");

const formSchema = new mongoose.Schema({
  formName: {
    type: String,
    required: true,
    trim: true,
  },
  fields: [
    {
      fieldName: {
        type: String,
        required: true,
        trim: true,
      },
      fieldType: {
        type: String,
        required: true,
        enum: [
          "text",
          "number",
          "email",
          "date",
          "select",
          "checkbox",
          "radio",
          "textarea",
        ],
        default: "text",
      },
      required: {
        type: Boolean,
        default: false,
      },
      options: [String], // Only used for select, radio, checkbox types
    },
  ],
  submissions: [
    {
      data: mongoose.Schema.Types.Mixed, // Flexible structure to store submission data
      submittedAt: {
        type: Date,
        default: Date.now,
      },
      submittedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User", // Reference to user if you have authentication
      },
    },
  ],
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Update the updatedAt field before saving
formSchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model("form", formSchema);
