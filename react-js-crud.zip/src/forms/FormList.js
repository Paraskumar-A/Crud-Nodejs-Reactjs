import React, { useEffect, useState } from "react";
import { getFormTemplates } from "../services/api";
import { Link } from "react-router-dom";

const FormList = () => {
  const [forms, setForms] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchForms = async () => {
      try {
        const data = await getFormTemplates();
        setForms(data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching forms:", error);
        setLoading(false);
      }
    };
    fetchForms();
  }, []);

  if (loading) return <div>Loading forms...</div>;

  return (
    <div className="form-list">
      <h2>Available Forms</h2>
      <ul>
        {forms.map((form) => (
          <li key={form._id}>
            <Link to={`/form/${form._id}`}>{form.formName}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default FormList;
