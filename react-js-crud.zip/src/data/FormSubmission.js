import React, { useState, useEffect } from "react";
import { getFormTemplateById, submitForm } from "../services/api";
import { useParams } from "react-router-dom";

const FormSubmission = () => {
  const { formId } = useParams();
  const [formTemplate, setFormTemplate] = useState(null);
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(true);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const fetchFormTemplate = async () => {
      try {
        const data = await getFormTemplateById(formId);
        setFormTemplate(data);

        // Initialize form data with empty values
        const initialData = {};
        data.fields.forEach((field) => {
          initialData[field.fieldName] = "";
        });
        setFormData(initialData);

        setLoading(false);
      } catch (error) {
        console.error("Error fetching form template:", error);
        setLoading(false);
      }
    };
    fetchFormTemplate();
  }, [formId]);

  const handleChange = (fieldName, value) => {
    setFormData({
      ...formData,
      [fieldName]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await submitForm(formId, formData);
      setSubmitted(true);
    } catch (error) {
      alert("Error submitting form");
    }
  };

  if (loading) return <div>Loading form...</div>;
  if (!formTemplate) return <div>Form not found</div>;

  if (submitted) {
    return (
      <div className="form-submitted">
        <h2>Thank You!</h2>
        <p>Your form has been submitted successfully.</p>
      </div>
    );
  }

  return (
    <div className="form-submission">
      <h2>{formTemplate.formName}</h2>
      <form onSubmit={handleSubmit}>
        {formTemplate.fields.map((field, index) => (
          <div key={index} className="form-field">
            <label>
              {field.fieldName}
              {field.required && <span className="required">*</span>}
            </label>

            {field.fieldType === "text" && (
              <input
                type="text"
                value={formData[field.fieldName] || ""}
                onChange={(e) => handleChange(field.fieldName, e.target.value)}
                required={field.required}
              />
            )}

            {field.fieldType === "email" && (
              <input
                type="email"
                value={formData[field.fieldName] || ""}
                onChange={(e) => handleChange(field.fieldName, e.target.value)}
                required={field.required}
              />
            )}

            {field.fieldType === "number" && (
              <input
                type="number"
                value={formData[field.fieldName] || ""}
                onChange={(e) => handleChange(field.fieldName, e.target.value)}
                required={field.required}
              />
            )}

            {field.fieldType === "textarea" && (
              <textarea
                value={formData[field.fieldName] || ""}
                onChange={(e) => handleChange(field.fieldName, e.target.value)}
                required={field.required}
              />
            )}

            {field.fieldType === "select" && (
              <select
                value={formData[field.fieldName] || ""}
                onChange={(e) => handleChange(field.fieldName, e.target.value)}
                required={field.required}
              >
                <option value="">Select an option</option>
                {field.options.map((option, i) => (
                  <option key={i} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            )}

            {field.fieldType === "radio" && (
              <div className="radio-options">
                {field.options.map((option, i) => (
                  <div key={i}>
                    <input
                      type="radio"
                      id={`${field.fieldName}-${i}`}
                      name={field.fieldName}
                      value={option}
                      checked={formData[field.fieldName] === option}
                      onChange={() => handleChange(field.fieldName, option)}
                      required={field.required}
                    />
                    <label htmlFor={`${field.fieldName}-${i}`}>{option}</label>
                  </div>
                ))}
              </div>
            )}

            {field.fieldType === "checkbox" && (
              <div className="checkbox-options">
                {field.options.map((option, i) => (
                  <div key={i}>
                    <input
                      type="checkbox"
                      id={`${field.fieldName}-${i}`}
                      value={option}
                      checked={
                        formData[field.fieldName]?.includes(option) || false
                      }
                      onChange={(e) => {
                        const currentValues = formData[field.fieldName] || [];
                        const newValues = e.target.checked
                          ? [...currentValues, option]
                          : currentValues.filter((val) => val !== option);
                        handleChange(field.fieldName, newValues);
                      }}
                    />
                    <label htmlFor={`${field.fieldName}-${i}`}>{option}</label>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}

        <button type="submit">Submit Form</button>
      </form>
    </div>
  );
};

export default FormSubmission;
