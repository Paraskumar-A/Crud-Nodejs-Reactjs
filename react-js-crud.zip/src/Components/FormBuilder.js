import React, { useState } from "react";
import { createFormTemplate } from "../services/api";

const FormBuilder = () => {
  const [formName, setFormName] = useState("");
  const [fields, setFields] = useState([]);
  const [newField, setNewField] = useState({
    fieldName: "",
    fieldType: "text",
    required: false,
    options: "",
  });

  const handleAddField = () => {
    const fieldToAdd = {
      ...newField,
      options: newField.options.split(",").map((opt) => opt.trim()),
    };
    setFields([...fields, fieldToAdd]);
    setNewField({
      fieldName: "",
      fieldType: "text",
      required: false,
      options: "",
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = { formName, fields };
      const createdForm = await createFormTemplate(formData);
      alert(`Form "${createdForm.formName}" created successfully!`);
      setFormName("");
      setFields([]);
    } catch (error) {
      alert("Error creating form template");
    }
  };

  return (
    <div className="form-builder">
      <h2>Create New Form Template</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Form Name:</label>
          <input
            type="text"
            value={formName}
            onChange={(e) => setFormName(e.target.value)}
            required
          />
        </div>

        <h3>Fields</h3>
        <div>
          <label>Field Name:</label>
          <input
            type="text"
            value={newField.fieldName}
            onChange={(e) =>
              setNewField({ ...newField, fieldName: e.target.value })
            }
          />
        </div>
        <div>
          <label>Field Type:</label>
          <select
            value={newField.fieldType}
            onChange={(e) =>
              setNewField({ ...newField, fieldType: e.target.value })
            }
          >
            <option value="text">Text</option>
            <option value="number">Number</option>
            <option value="email">Email</option>
            <option value="date">Date</option>
            <option value="select">Select</option>
            <option value="checkbox">Checkbox</option>
            <option value="radio">Radio</option>
            <option value="textarea">Textarea</option>
          </select>
        </div>
        <div>
          <label>
            Required:
            <input
              type="checkbox"
              checked={newField.required}
              onChange={(e) =>
                setNewField({ ...newField, required: e.target.checked })
              }
            />
          </label>
        </div>
        {["select", "checkbox", "radio"].includes(newField.fieldType) && (
          <div>
            <label>Options (comma separated):</label>
            <input
              type="text"
              value={newField.options}
              onChange={(e) =>
                setNewField({ ...newField, options: e.target.value })
              }
            />
          </div>
        )}
        <button type="button" onClick={handleAddField}>
          Add Field
        </button>

        <h4>Current Fields</h4>
        <ul>
          {fields.map((field, index) => (
            <li key={index}>
              {field.fieldName} ({field.fieldType}){" "}
              {field.required ? "*required" : ""}
              {field.options && ` Options: ${field.options.join(", ")}`}
            </li>
          ))}
        </ul>

        <button type="submit">Create Form Template</button>
      </form>
    </div>
  );
};

export default FormBuilder;
