import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import FormSubmission from "./data/FormSubmission";
import FormList from "./forms/FormList";
import FormBuilder from "./Components/FormBuilder";

function App() {
  return (
    <Router>
      <div className="App">
        <header>
          <h1>Form Management System</h1>
        </header>
        <main>
          <Routes>
            <Route path="/" element={<FormList />} />
            <Route path="/create-form" element={<FormBuilder />} />
            <Route path="/form/:formId" element={<FormSubmission />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
