import axios from "axios";

const API_BASE_URL = "http://localhost:5000/api/forms";

export const createFormTemplate = async (formData) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/templates`, formData);
    return response.data;
  } catch (error) {
    console.error("Error creating form template:", error);
    throw error;
  }
};

export const getFormTemplates = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/templates`);
    return response.data;
  } catch (error) {
    console.error("Error fetching form templates:", error);
    throw error;
  }
};

export const getFormTemplateById = async (id) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/templates/${id}`);
    return response.data;
  } catch (error) {
    console.error("Error fetching form template:", error);
    throw error;
  }
};

export const submitForm = async (formId, formData) => {
  try {
    const response = await axios.post(
      `${API_BASE_URL}/submit/${formId}`,
      formData
    );
    return response.data;
  } catch (error) {
    console.error("Error submitting form:", error);
    throw error;
  }
};

export const getFormSubmissions = async (formId) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/submissions/${formId}`);
    return response.data;
  } catch (error) {
    console.error("Error fetching form submissions:", error);
    throw error;
  }
};
